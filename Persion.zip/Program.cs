﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Persion
{
  class Person
  {
        private string name;
        private int age;
        
        public string Name{
            get { return name; }
            set { name = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        public string Info
        {
            get { return name + " " + age; }
        }
        public Person(string name, int age) 
        {
            this.name = name;
            this.age = age;
        }

        public Person(int age)
        {
            this.age = age;
        }

        public Person(string name)
        {
            this.name = name;
        }
         public Person() :this("",0){ }

        void sayHello(string s)
        { Console.WriteLine("hello!my name is"+s); }

        void sayHello() { Console.WriteLine("Hello,World!"); }


        public bool IsAgeThan(Person person)
        {
            if(age < this.age) { return true; } return false;
        }

        //static void Main(string[] args)
        //{
        //    Person p1 = new Person("张三",20);
        //    Person p2 = new Person("李四");
        //    Person p3= new Person(34);
        //    Person p4 = new Person("王五", 27);
        //    Console.WriteLine("姓名："+p1.name+",年龄："+p1.age);
        //    Console.WriteLine("姓名：" + p2.name + ",年龄：" + p2.age);
        //    Console.WriteLine("姓名：" + p3.name + ",年龄：" + p3.age);
        //    if (p1.IsAgeThan(p4))
        //    {
        //        Console.WriteLine(p1.name + "比" + p4.name + "年纪小。");
        //    }
        //    else
        //    {
        //        Console.WriteLine(p1.name + "比" + p4.name + "年纪大。");
        //    }
        //}
  }
    class test
    {
        static void Main(string[] args)
        {
            Person p1 = new Person("张三", 20);
            Person p2 = new Person("李四");
            Person p3 = new Person(34);
            Person p4 = new Person("王五", 27);
            Console.WriteLine("姓名：" + p1.Name + ",年龄：" + p1.Age);
            Console.WriteLine("姓名：" + p2.Name + ",年龄：" + p2.Age);
            Console.WriteLine("姓名：" + p3.Name + ",年龄：" + p3.Age);
            p2.Age = 21;
            Console.WriteLine("李四修改后年龄："+p2.Age);
            if (p1.IsAgeThan(p4))
            {
                Console.WriteLine(p1.Name + "比" + p4.Name + "年纪小。");
            }
            else
            {
                Console.WriteLine(p1.Name + "比" + p4.Name + "年纪大。");
            }
        }
    }
}
